# Mengimpor modul sys untuk exit()
import sys
def main():
    #Membuat judul program
    print("PROGRAM PEMBAGIAN BILANGAN")

    #Meminta user memasukkan bilangan
    a = float(input("Masukkan nilai a: "))
    b = float(input("Masukkan nilai b: "))

    #Mendefinisikan blok try ... except
    try:
        hasil = a/b
    except ZeroDivisionError:
        print("\nERROR: Nilai b tidak boleh nol")
        sys.exit(1) #Menghentikan Exit

    #Menampilkan hasil
    print("\na : ", a)
    print("b : ", b)
    print("a/b = ", hasil)

if __name__ == "__main__":
    main()